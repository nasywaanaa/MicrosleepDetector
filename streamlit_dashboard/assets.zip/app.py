import streamlit as st

st.set_page_config(page_title="Microsleep Dashboard", layout="wide")

st.title("Selamat Datang di Microsleep Detection System")

st.markdown("""
Dashboard ini membantu memantau dan menganalisis deteksi microsleep pada sopir.
""")
