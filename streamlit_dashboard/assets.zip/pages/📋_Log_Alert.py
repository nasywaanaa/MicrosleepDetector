import streamlit as st
import pandas as pd

if not st.session_state.get("logged_in"):
    st.warning("Anda harus login untuk mengakses halaman ini.")
    st.stop()

st.title("Log Alert dan Riwayat Microsleep")

# Load data
df = pd.read_csv("assets/microsleep_log.csv")
df['timestamp'] = pd.to_datetime(df['timestamp'])
df['date'] = df['timestamp'].dt.date
df['hour'] = df['timestamp'].dt.hour

# Tambah kolom shift
def tentukan_shift(jam):
    if 6 <= jam < 14:
        return "Shift Pagi"
    elif 14 <= jam < 22:
        return "Shift Siang"
    else:
        return "Shift Malam"

df['shift'] = df['hour'].apply(tentukan_shift)

# Sidebar atau expander filter
st.subheader("Filter Riwayat Microsleep")
with st.expander("Filter Data"):
    col1, col2 = st.columns(2)

    with col1:
        selected_sopir = st.multiselect("Nama Sopir", options=sorted(df['nama_sopir'].unique()))
        selected_armada = st.multiselect("Armada", options=sorted(df['armada'].unique()))
        selected_shift = st.multiselect("Shift", options=["Shift Pagi", "Shift Siang", "Shift Malam"])

    with col2:
        selected_rute = st.multiselect("Rute", options=sorted(df['rute'].unique()))
        selected_tanggal = st.multiselect("Tanggal", options=sorted(df['date'].unique()))
        selected_status = st.multiselect("Status Alert", options=sorted(df['status_alert'].unique()))

# Terapkan filter
if selected_sopir:
    df = df[df['nama_sopir'].isin(selected_sopir)]
if selected_armada:
    df = df[df['armada'].isin(selected_armada)]
if selected_shift:
    df = df[df['shift'].isin(selected_shift)]
if selected_rute:
    df = df[df['rute'].isin(selected_rute)]
if selected_tanggal:
    df = df[df['date'].isin(selected_tanggal)]
if selected_status:
    df = df[df['status_alert'].isin(selected_status)]

# Tampilkan hasil
st.subheader("Hasil Filter Riwayat Microsleep")
st.dataframe(df[['nama_sopir', 'timestamp', 'armada', 'rute', 'shift', 'status_alert']])
