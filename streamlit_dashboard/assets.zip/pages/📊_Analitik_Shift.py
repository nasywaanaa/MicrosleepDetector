import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

if not st.session_state.get("logged_in"):
    st.warning("Anda harus login untuk mengakses halaman ini.")
    st.stop()

st.set_page_config(page_title="Analitik Kelelahan dan Shift", layout="wide")
st.title("Analitik Kelelahan dan Shift")

# Load data
df = pd.read_csv("assets/microsleep_log.csv")
df['timestamp'] = pd.to_datetime(df['timestamp'])
df['date'] = df['timestamp'].dt.date
df['hour'] = df['timestamp'].dt.hour

# ==========================
# 📊 Heatmap Jam vs Hari
# ==========================
st.subheader("🕒 Heatmap Jam Rawan dalam Seminggu")

# Ekstrak hari dalam bahasa Indonesia
df['weekday'] = df['timestamp'].dt.day_name()
hari_mapping = {
    'Monday': 'Senin',
    'Tuesday': 'Selasa',
    'Wednesday': 'Rabu',
    'Thursday': 'Kamis',
    'Friday': 'Jumat',
    'Saturday': 'Sabtu',
    'Sunday': 'Minggu'
}
df['hari'] = df['weekday'].map(hari_mapping)

# Buat pivot table jam vs hari
heatmap_data = df.groupby(['hour', 'hari']).size().unstack(fill_value=0)

# Urutkan kolom hari
ordered_days = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu']
for hari in ordered_days:
    if hari not in heatmap_data.columns:
        heatmap_data[hari] = 0
heatmap_data = heatmap_data[ordered_days]

# Buat heatmap
fig_heatmap = go.Figure(data=go.Heatmap(
    z=heatmap_data.values,
    x=heatmap_data.columns,
    y=[f"{h}:00" for h in heatmap_data.index],
    colorscale='Reds',
    colorbar=dict(title='Jumlah Microsleep'),
    hoverongaps=False
))

fig_heatmap.update_layout(
    xaxis_title='Hari',
    yaxis_title='Jam (24 Jam)',
    height=600
)

st.plotly_chart(fig_heatmap, use_container_width=True)

# ==========================
# 📈 Tren Jumlah Harian
# ==========================
st.subheader("📈 Tren Jumlah Microsleep Harian")

trend = df.groupby('date').size().reset_index(name='jumlah')
fig_line = px.line(
    trend,
    x='date', y='jumlah',
    markers=True,
    labels={"jumlah": "Jumlah Microsleep", "date": "Tanggal"},
    title="Pergerakan Jumlah Microsleep per Hari"
)
st.plotly_chart(fig_line, use_container_width=True)
